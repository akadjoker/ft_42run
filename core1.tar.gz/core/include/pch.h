
#include <SDL2/SDL.h>

#include <time.h>
#include <sys/stat.h> 
#include <climits>
#include <stdio.h>
#include <stdlib.h>
#include <cstring>


#include <new>
#include <utility>
#include <typeinfo>



#include <set>
#include <map>
#include <unordered_map>
#include <functional>
#include <string>
#include <cstring>
#include <vector>
#include <iostream>
#include <fstream>
#include <sstream>











